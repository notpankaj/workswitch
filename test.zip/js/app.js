const navToggleBtn = document.querySelector('#navToggle');
const mobNavList= document.querySelector('.mobile-nav-list');

navToggleBtn.addEventListener('click', e => {
    mobNavList.classList.toggle('active');
} );
